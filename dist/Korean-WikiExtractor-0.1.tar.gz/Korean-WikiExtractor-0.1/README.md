# Korean-WikiExtractor

convert MediaWiki to plain text
